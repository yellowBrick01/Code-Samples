acs_or$age_husband
acs_or[1,3]
a = subset(acs_or,age_husband > age_wife)
a <- subset(acs_or, age_husband > age_wife)
mean(acs_or$age_husband)
median(acs_or$age_wife)
quantile(acs_or$age_wife)
var(acs_or$age_wife)
sd(acs_or$age_wife)
plot(x = acs_or$age_husband
     , y = acs_or$age_wife
     , type = 'p')
hist(acs_or$number_children)
counts = table(acs_or$bedrooms)
barplot(counts
        , main = "Bedrooms Distribution"
        , xlab = "Number of Bedrooms")
