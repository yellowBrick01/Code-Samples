# Groupings by medal(Start)

gold_group <- subset(myDataset , Medal == 'Gold')
View(gold_group)
mean(gold_group$BMI)
hist(gold_group$BMI)
plot(x = gold_group$Height
     , y = gold_group$Weight
     , type = 'p') 
x <- sd(gold_group$BMI)
mean(gold_group$BMI) + 3*x
mean(gold_group$BMI) - 3*x
silver_group <-subset(myDataset, Medal == 'Silver')
View(silver_group)
mean(silver_group$BMI)

bronze_group <- subset(myDataset, Medal == 'Bronze')
mean(bronze_group$BMI)
View(bronze_group)

#Groupings by medal (End)

#Groupings by Bmi (start)

healthy_group <- subset(myDataset, Healty_BMI == 'Healthy BMI')
View(healthy_group)

overweight_group <- subset(myDataset, Healty_BMI == 'Overweight')
View(overweight_group)

#Groupings by Bmi (End)

#Groupings by ERA (Start)

modern_group <- subset(myDataset, Era == 'Modern Age')
mean(modern_group$BMI)
View(modern_group)

post_ww2_group <- subset(myDataset, Era == 'Post WW2')
mean(post_ww2_group$BMI)
View(post_ww2_group)

pre_mechanised_farming_group <- subset(myDataset, Era == 'Pre Mechanised Farming')
mean(pre_mechanised_farming_group$BMI)
View(pre_mechanised_farming_group)

#Groupings by ERA (End)

three_medals_bmi <- vector(mean(gold_group$BMI)
                          , mean(silver_group$BMI)
                          , mean(bronze_group$BMI))
barplot(three_medals_bmi)
