import java.util.Scanner;

public class Find2Max{
    public static void main(String [] args){
        Scanner userInput = new Scanner(System.in);
        int numOfStudents;
        String studentName;
        String studentMax;
        String studentMaxTwo;
        double studentScore;
        int x = 1;
        
        System.out.print("Enter the number of at least 2 students: ");
        numOfStudents = userInput.nextInt();
        while(x == numOfStudents || x == 2){
            System.out.print("Enter a student name: ");
            studentName = userInput.nextLine();
            userInput.nextLine();
            System.out.print("Enter a student score: ");
            studentScore = userInput.nextDouble();
            x++;
        }
        if(x == 1){
            double max = 0;
            double maxTwo = 0;
            studentMax = studentName;
            max = studentScore;
            if(x == 2){
                studentMaxTwo = studentName;
                maxTwo = studentScore;
                System.out.println("Top two students:");
                System.out.println(studentMax+"'s score is"+max);
                System.out.println(studentMaxTwo+"'s score is"+maxTwo);
            }
        }else{
            if(studentScore> max && studentScore> maxTwo){
                studentMax = studentName;
                max = studentScore;
                if(studentScore> maxTwo && studentScore< max){
                    studentMaxTwo = studentName;
                    maxTwo = studentScore;
                    System.out.println("Top two students:");
                    System.out.println(studentMax+"'s score is"+max);
                    System.out.println(studentMaxTwo+"'s score is"+maxTwo);
                }
            }
        }
    }
}