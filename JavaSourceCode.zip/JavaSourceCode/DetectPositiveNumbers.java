import java.util.Scanner;

public class DetectPositiveNumbers{
    public static void main(String[] args){
        Scanner userInput = new Scanner(System.in);
        int userNum;
        int total;
        double count=0;
        int countPos = 0;
        int countNeg = 0;
        System.out.println("Enter integers below, program ends when 0 is entered:");
        userNum = userInput.nextInt();
        total = userNum;
        
        if(userNum<0){
            countNeg = countNeg+1;
        }else{
            if(userNum>0){
                countPos = countPos+1;
            }
        }
        
        if(userNum == 0){
            System.out.println("no numbers are entered except 0");
        }else{
            while(userNum != 0){
                userNum = userInput.nextInt();
                total = total+userNum;
                count= count + 1;
                if(userNum<0){
                    countNeg = countNeg+1;
                }else{
                    if(userNum>0){
                        countPos = countPos+1;
                    }
                }
            }
            
            double average = total/count;
            System.out.println("The number of positives is "+countPos);
            System.out.println("The number of negatives is "+countNeg);
            System.out.println("The total is "+total);
            System.out.println("The average is "+average);
        }
    }
}