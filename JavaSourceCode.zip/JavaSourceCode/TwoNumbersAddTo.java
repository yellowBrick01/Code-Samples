import java.util.*;

public class TwoNumbersAddTo{
    public static void main (String [] args){
        Scanner userInput = new Scanner(System.in);
        int numGoal;
        int userNum;
        int[] arrayOfUserNums = new int[20];
        
        System.out.print("enter goal: ");
        numGoal = userInput.nextInt();
        System.out.println("enter at most 20 integers, end with 0:");
        for(int i = 0; i < arrayOfUserNums.length; i++ ){
            userNum = userInput.nextInt();
            if(userNum == 0){
                break;
            }else{
                arrayOfUserNums[i] = userNum;
            }
        }
        for(int i = 0; i < arrayOfUserNums.length; i++){
            for(int u = i + 1; u < arrayOfUserNums.length; u++){
                if((arrayOfUserNums[i] + arrayOfUserNums[u]) == numGoal)
                    System.out.println(arrayOfUserNums[i]+" + "+arrayOfUserNums[u]+" = "+numGoal);
            }
        }        
    }
}