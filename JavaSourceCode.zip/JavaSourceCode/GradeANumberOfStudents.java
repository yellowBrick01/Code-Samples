import java.util.*;
public class GradeANumberOfStudents{
    public static void main(String[] args){
        Scanner userInput = new Scanner(System.in);
        int numOfStudents;//Determines the length of array
        double tempScore;//Holds the student score for method setScore
        String tempFName;//Holds the student first name for method setFName
        String tempLName;//Holds the student last name for method setLName
        char grade;//Will be based of the student score
        
        //Determines length and creates the array of Students
        System.out.print("Enter number of students: ");
        numOfStudents = userInput.nextInt();
        Student[] arrayOfStudents = new Student[numOfStudents];
        
        //Gives values to the array of Students
        for(int i = 0; i < arrayOfStudents.length; i++){
            arrayOfStudents[i] = new Student(0, "", "");//defult values.
            System.out.print("Enter score for student "+(i +1)+": ");
            tempScore = userInput.nextDouble();    
            arrayOfStudents[i].setScore(tempScore);//calls the setScore method to tranfers info to the Student class
            userInput.nextLine();
            System.out.print("Enter first name for student "+(i +1)+": ");
            tempFName = userInput.nextLine();
            arrayOfStudents[i].setFName(tempFName);//calls the setFName method to tranfers info to the Student class
            System.out.print("Enter last name for student "+(i + 1)+": ");
            tempLName = userInput.nextLine();
            arrayOfStudents[i].setLName(tempLName);//calls the setLName method to tranfers info to the Student Clas
        }
        
        //Gives the grade and display the result. Only when there are students to grade         
        if(numOfStudents != 0){
            System.out.println("Student    First     Last Score Grade");
            for(int i = 0; i < arrayOfStudents.length; i++){
                if(arrayOfStudents[i].getScore() >= 90){
                    grade = 'A';
                    if(arrayOfStudents[i].getScore() >= 100){
                        System.out.printf("%7d %8s %8s %5.1f %5c\n",(i +1),arrayOfStudents[i].getFirst(),arrayOfStudents[i].getLast(),arrayOfStudents[i].getScore(),grade);
                    }else{
                        System.out.printf("%7d %8s %8s %5.1f %5c\n",(i +1),arrayOfStudents[i].getFirst(),arrayOfStudents[i].getLast(),arrayOfStudents[i].getScore(),grade);    
                    }                
                }else{
                    if(arrayOfStudents[i].getScore() >= 80 && arrayOfStudents[i].getScore() < 90){
                        grade = 'B';
                        System.out.printf("%7d %8s %8s %5.1f %5c\n",(i +1),arrayOfStudents[i].getFirst(),arrayOfStudents[i].getLast(),arrayOfStudents[i].getScore(),grade);
                    }else{
                        if(arrayOfStudents[i].getScore() >= 70 && arrayOfStudents[i].getScore() < 80){
                            grade = 'C';
                            System.out.printf("%7d %8s %8s %5.1f %5c\n",(i +1),arrayOfStudents[i].getFirst(),arrayOfStudents[i].getLast(),arrayOfStudents[i].getScore(),grade);
                        }else{
                            if(arrayOfStudents[i].getScore() >= 60 && arrayOfStudents[i].getScore() < 70){
                                grade = 'D';
                                System.out.printf("%7d %8s %8s %5.1f %5c\n",(i +1),arrayOfStudents[i].getFirst(),arrayOfStudents[i].getLast(),arrayOfStudents[i].getScore(),grade);
                            }else{
                                if(arrayOfStudents[i].getScore() < 60){
                                    grade = 'F';
                                    System.out.printf("%7d %8s %8s %5.1f %5c\n",(i +1),arrayOfStudents[i].getFirst(),arrayOfStudents[i].getLast(),arrayOfStudents[i].getScore(),grade);
                                }
                            }
                        }                            
                    }
                }    
            }          
        }
        
    }
}
class Student{
    double score;
    String firstName;
    String lastName;
    
    //Constructor for the student class. Will have a double and two Strings
    public Student(double ss, String ff, String ll){
        score = ss;
        firstName = ff;
        lastName = ll;
    }
    
    //All the methods that are used in this class
    public double getScore(){
        return score;
    }
    //Get the student score from tempScore and tranfers information to score
    public void setScore(double ss){
        score = ss;
    }
    public String getFirst(){
        return firstName;
    }
    //Get the student first name from tempFName and tranfers information to firstName
    public void setFName(String ff){
        firstName = ff;
    }
    public String getLast(){
        return lastName;
    }
    //Get the student last name from tempLName and tranfers information to lastName
    public void setLName(String ll){
        lastName = ll;
    }
}