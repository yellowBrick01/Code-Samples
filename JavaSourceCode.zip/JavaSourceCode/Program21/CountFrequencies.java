import java.util.*;
import java.io.*;

public class CountFrequencies{
    public static void main (String[] args) throws Exception{
        Scanner user_input = new Scanner(System.in);
        String user_text_file;
        String s = "";
        String s_format = "";
        System.out.print("enter file name: ");
        user_text_file = user_input.nextLine();
        
        File file_to_read = new File(user_text_file);
        Scanner file_reader = new Scanner(file_to_read);
        
        while(file_reader.hasNext()){
            s = s + file_reader.next()+" ";
        }
        
        StringTokenizer stk = new StringTokenizer(s, ".,? !'\":;[]{}()-{}", false);
        while(stk.hasMoreTokens()){
            s_format = s_format +stk.nextToken()+ " ";
        }
        
        String [] words = s_format.split("\\s+");
        TreeMap<String , Integer> text_map = new TreeMap<String, Integer>();
        for(int i = 0; i < words.length; i++){
            String tree_map_key = words[i];
            if(text_map.get(tree_map_key) == null){
                text_map.put(tree_map_key, 1);
            }else{
                int value = text_map.get(tree_map_key).intValue();
                value ++;
                text_map.put(tree_map_key, value);
            }             
        }
        for(Map.Entry<String, Integer> entry : text_map.entrySet()){
            String key = entry.getKey();
            Integer value = entry.getValue();
            
            System.out.println(key+"  "+value);
        }
    }
}