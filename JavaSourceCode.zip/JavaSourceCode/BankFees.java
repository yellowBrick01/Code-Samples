import java.util.Scanner;

public class BankFees
{
    public static void main (String [] args)
    {
        Scanner userInput = new Scanner(System.in);
        int caseNum = 8;
        int check;
        double balanceStarting;
        double fee = 9;
        
        System.out.print("enter initial balance: ");
        balanceStarting = userInput.nextDouble();
        System.out.print("enter number of checks written during the month: ");
        check = userInput.nextInt();
        
        if(check < 20){
            if(balanceStarting < 400){
                fee = 10 + .10 * check + 15;
                System.out.println("fees: " + fee);    
            }else{
                fee = 10 + .10 * check;
                System.out.println("fees: " + fee);
            }              
        }else{
            if(check >= 20 && check <= 39){
                if(balanceStarting < 400){
                    fee = 10 + .08 * check + 15;
                    System.out.println("fees: " + fee);
                }else {
                    fee = 10 + .08 * check;
                    System.out.println("fees: " + fee);
                }
            }else {
                if(check >= 40 && check <= 59){
                    if(balanceStarting < 400){
                        fee = 10 + .06 * check + 15;
                        System.out.println("fees: " + fee);
                    }else{
                        fee = 10 + .06 * check;
                        System.out.println("fees: " + fee);
                    }        
                }else{
                                
                    if(check >= 60){
                        if (balanceStarting < 400){
                            fee = 10 + .04 * check + 15;
                            System.out.println("fees: " + fee);
                        }else {
                            fee = 10 + .04 * check;
                            System.out.println("fees: " + fee);
                        }     
                    }
                }    
            }    
        }   
    }
}
