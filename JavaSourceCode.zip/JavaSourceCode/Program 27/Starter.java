import java.util.Scanner;
import java.util.ArrayList;
public class PrintTree {

    public static TreeNode tree;

    public static void main(String [] args){
        Scanner input = new Scanner(System.in);
        System.out.print("please enter an int: ");
        int ll = input.nextInt();
        //the integer read from the user determines which tree is
        //going to be used
        
        TreeFactory factory = new TreeFactory();
        //the Tree factory creates a different Tree for each integer
        tree = factory.getTree(ll);

        //now variable tree refers to one of the trees from the factory

        //print the tree here
        
    }
}
