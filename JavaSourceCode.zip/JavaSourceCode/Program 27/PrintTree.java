import java.util.Scanner;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
public class PrintTree {

    public static TreeNode tree;

    static void inOrderTraversTree(TreeNode tree){
        if(tree == null)
            return;
        Queue<TreeNode> q = new LinkedList <TreeNode>();
        q.add(tree);
        
        while(!q.isEmpty()){
            int nodeCount = q.size();
            if(nodeCount == 0)
                break;
            while(nodeCount > 0){
                TreeNode sub_tree = (TreeNode)q.remove();
                System.out.print(sub_tree.item+"  ");
                if(sub_tree.left != null)
                    q.add(sub_tree.left);
                if(tree.right != null)
                    q.add(sub_tree.right);
                nodeCount --;
            }
            System.out.println();
        }
        
    }
    
    public static void main(String [] args){
        Scanner input = new Scanner(System.in);
        System.out.print("please enter an int: ");
        int ll = input.nextInt();
        //the integer read from the user determines which tree is
        //going to be used
        
        TreeFactory factory = new TreeFactory();
        //the Tree factory creates a different Tree for each integer
        tree = factory.getTree(ll);
        //now variable tree refers to one of the trees from the factory
        inOrderTraversTree(tree);
        //print the tree here
        
    }
}
class VerifyBST{
    
}