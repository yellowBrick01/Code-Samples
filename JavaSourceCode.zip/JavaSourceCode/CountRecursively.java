import java.util.*;
public class CountRecursively{
    public static void main (String [] args){
        Scanner userInput = new Scanner(System.in);
        int userNum;
        
        System.out.print("enter an integer: ");
        userNum = userInput.nextInt();
        CountRecursively.message(userNum);
    }
    public static void message(int userNum){
        if(userNum >= 0){
            System.out.println(userNum);
            message(userNum - 2);
        }    
    }
}