import java.util.*;

public class Binary{
    public static void main(String [] args){
        Scanner userInput = new Scanner(System.in);
        int numOfDigits;
        int maxNum;
        int index = 0;
        
        System.out.print("enter number of digits: ");
        numOfDigits = userInput.nextInt();
        System.out.print("enter maximum: ");
        maxNum = userInput.nextInt();
        
        for(int i = 0; i <= maxNum; i ++){
            int x = i;
            String temp = ""; 
            String tempFormatted = "";
            
            if(x == 0 && numOfDigits == 0)
                break;
            if(x == 0){
                System.out.printf("%0"+numOfDigits+"d\n", x);
            }else{
                int [] binaryArray = decToBinary(x);
                while(x != 0){
                    temp = x % 2 + temp;
                    x = x/2;
                }
                if(numOfDigits < temp.length()){
                    System.out.printf("%0"+numOfDigits+"d\n", 0);
                }else{
                    tempFormatted = String.format("%0"+numOfDigits+"d", Integer.parseInt(temp));
                    System.out.println(tempFormatted);
                }
            }            
        }    
    }
    public static int[] decToBinary(int x){
        int[] bin = new int [100];
        int index_Of_Bin = 0;
        while(x != 0){
            bin[index_Of_Bin] = x % 2;
            x = x/2;
            index_Of_Bin ++;
        }            
        return bin;        
    }
}    