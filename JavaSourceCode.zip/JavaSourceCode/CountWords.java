import java.util.*;

public class CountWords{
    public static void main(String [] args){
        Word[] arrayofWords = new Word[1001];
        for(int i = 0; i < arrayofWords.length; i++){
            arrayofWords[i] = new Word();
        }
        String userString;
        Scanner userInput = new Scanner(System.in);
        int countString = 1;
        System.out.println("Enter at most 1000 lines:");
        System.out.print("finish by entering a line containing only 0: ");
        for(int i = 0; i < arrayofWords.length; i++){
            userString = userInput.nextLine();
            if(userString.equals("0")){
                break;
            }else{
                for(int u = 0; u < arrayofWords.length; u ++){
                    arrayofWords[i].countString = 0;
                    if(userString.equals(arrayofWords[u].statement)){
                        arrayofWords[u].countString++;
                        break;
                    }else{
                        arrayofWords[i].statement = userString;
                        arrayofWords[i].countString++;
                    }
                }
            }
        }
        for(int i = 0; i < arrayofWords.length; i++){
            if(arrayofWords[i].statement != null){
                if (arrayofWords[i].countString > 0){
                    if(arrayofWords[i].countString == 1){
                        System.out.println(arrayofWords[i].getStatement()+" occurs "+arrayofWords[i].getCount()+" time");
                    }else{
                        System.out.println(arrayofWords[i].getStatement()+" occurs "+arrayofWords[i].getCount()+" times");
                    }
                }
            }
        }    
    }    
}
class Word{
    String statement;
    int countString;
    public String getStatement(){
        return statement;
    }
    public int getCount(){
        return countString;
    }
}    