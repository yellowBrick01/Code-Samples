import java.util.*;

public class AddNumbers{
    public static void main(String[] args){
        Scanner userInput = new Scanner(System.in);
        String userStatement;
        String newformat;
        int result = 0;
        
        System.out.print("enter numbers: ");
        userStatement = userInput.nextLine();
        newformat = userStatement.replace("-", " -");
        // I hade to reformat the user's statement because when I tokenizer  
        // negative numbers without a space the program whould run into an  
        // number format exception. 

        StringTokenizer stk = new StringTokenizer(newformat, "+ ", false);
        
        while(stk.hasMoreTokens()){
            result = result + Integer.parseInt(stk.nextToken());
        }
        System.out.print("result: " + result);        
    }    
}