import java.util.Scanner;

public class Students
{
    public static void main (String [] args)
    {
        Scanner userInput = new Scanner(System.in);
        
        int caseNum = 6;
        
        String nameOne;
        double scoreOne;
        
        String nameTwo;
        double scoreTwo;
        
        String nameThree;
        double scoreThree;
        
        System.out.print("enter student1 name: ");
        nameOne = userInput.nextLine();
        System.out.print("enter student1 score: ");
        scoreOne = userInput.nextDouble();
        
        userInput.nextLine();
        
        System.out.print("enter student2 name: ");
        nameTwo = userInput.nextLine();
        System.out.print("enter student2 score: ");
        scoreTwo = userInput.nextDouble();
        
        userInput.nextLine();
        
        System.out.print("enter student3 name: ");
        nameThree = userInput.nextLine();
        System.out.print("enter student3 score: ");
        scoreThree = userInput.nextDouble();
        
        if (scoreOne > scoreTwo && scoreOne > scoreThree)
            {
                if (scoreTwo > scoreThree)
                    {
                        caseNum = 1;
                    }
                else 
                    {
                        caseNum = 2;
                    }    
            }
        else 
            {
                if (scoreTwo > scoreOne && scoreTwo > scoreThree)
                    {
                        if (scoreOne > scoreThree)
                            {
                                caseNum = 3;
                            }
                        else 
                            {
                                caseNum = 4;
                            }    
                    }
                    else
                        {
                            if (scoreThree > scoreOne && scoreThree > scoreTwo)
                                {
                                    if (scoreOne > scoreTwo)
                                        {
                                            caseNum = 5;
                                        }
                                    else 
                                        {
                                            caseNum = 6;
                                        }    
                                }
                            
                        }    
            }
        
            switch (caseNum){
            
            case 1:
                System.out.println("first place student: " + nameOne);
                System.out.println("second place student: " + nameTwo);
                System.out.println("third place student: " + nameThree);
                break;
                
            case 2:
                System.out.println("first place student: " + nameOne);
                System.out.println("second place student: " + nameThree);
                System.out.println("third place student: " + nameTwo);
                break;
            
            case 3:
                System.out.println("first place student: " + nameTwo);
                System.out.println("second place student: " + nameOne);
                System.out.println("third place student: " + nameThree);
                break;
            
            case 4:
                System.out.println("first place student: " + nameTwo);
                System.out.println("second place student: " + nameThree);
                System.out.println("third place student: " + nameOne);
                break;
            
            case 5:
                System.out.println("first place student: " + nameThree);
                System.out.println("second place student: " + nameOne);
                System.out.println("third place student: " + nameTwo);
                break;
            
            case 6:
                System.out.println("first place student: " + nameThree);
                System.out.println("second place student: " + nameTwo);
                System.out.println("third place student: " + nameOne);
                break;
            
            default:
                System.out.println("ERROR: The students score must be different");
                break;
        }
            
    }
}