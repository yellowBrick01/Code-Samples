import java.util.Scanner;

public class TraverseaString{
        public static void main(String[] args){
            Scanner userInput = new Scanner(System.in);
            System.out.print("enter a string: ");
            String userString = userInput.nextLine();
            int nChar = userString.length();
            
            for(int i = 0; i < nChar; i++){
                System.out.println(userString.substring(i,i + 1));
            }
        }
}
