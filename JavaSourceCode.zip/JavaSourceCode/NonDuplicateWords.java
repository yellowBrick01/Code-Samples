import java.util.*;
import java.io.*;
//Uppercase w.
public class NonDuplicateWords{
    public static void main (String [] args) throws Exception{
        Scanner user_input = new Scanner(System.in);
        String user_text_file;
        Set <String> text_set = new TreeSet<String>();
        String s = "";
        
        System.out.print("enter file name: ");
        user_text_file = user_input.nextLine();
        
        File file_to_read = new File(user_text_file);
        Scanner file_reader = new Scanner(file_to_read);

        while(file_reader.hasNext()){
            s = s + file_reader.next()+" ";
        }
        StringTokenizer stk = new StringTokenizer(s, ".,? !'\":;[]{}()-", false);
        while(stk.hasMoreTokens()){
            text_set.add(stk.nextToken());
        }
        System.out.println("Display words in alphabetical order:");
        Iterator <String> itr = text_set.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());    
        }
        
    }
}