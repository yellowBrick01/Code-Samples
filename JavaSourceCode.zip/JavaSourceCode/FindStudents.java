import java.util.*;

public class FindStudents{
    public static void main (String [] args){
        Scanner userInput = new Scanner(System.in);
        int searchAge;
        String searchCity;
        Student[] studentData = new Student[101];
        //Start of the list of students
        studentData[0] = new Student("Diann", "Palomba", 23, "Los Angeles");
        studentData[1] = new Student("Abram", "anwart", 45, "Tarnov");
        studentData[2] = new Student("Addie", "Abdullah", 19, "Mill City");
        studentData[3] = new Student("Alex", "Audette", 31, "Seven Springs");
        studentData[4] = new Student("Alfreda", "Dever", 10, "Beasley");
        studentData[5] = new Student("Alia", "Pittman", 59, "Edmonston");
        studentData[6] = new Student("Andera", "Pegram",  37, "Hickory Hills");
        studentData[7] = new Student("Audrey", "Ramsdell", 48, "North Judson");
        studentData[8] = new Student("Beverly", "Espey", 58, "Santa Ana");
        studentData[9] = new Student("Billi", "Schillinger", 14, "New Paris");
        studentData[10] = new Student("Britney", "Barco", 34, "Lorimor");
        studentData[11] = new Student("Brittny", "Brownstein", 26, "Los Angeles");
        studentData[12] = new Student("Caitlyn", "Colin", 6, "Palm Springs");
        studentData[13] = new Student("Camie", "Freeburg", 32, "Tarnov");
        studentData[14] = new Student("Chadwick", "Gram", 54, "Mill City");
        studentData[15] = new Student("Cherry", "Curnutte", 40, "Seven Springs");
        studentData[16] = new Student("Corrie", "Lor", 51, "Beasley");
        studentData[17] = new Student("Cristine", "Catanzaro", 35, "Edmonston");
        studentData[18] = new Student("Dagmar", "Koziel", 57, "Hickory Hills");
        studentData[19] = new Student("Danyelle", "Diener", 28, "North Judson");
        studentData[20] = new Student("Darby", "Defazio", 52, "Santa Ana");
        studentData[21] = new Student("Dario", "Volz", 17, "New Paris");
        studentData[22] = new Student("Daysi", "Deveau", 43, "Lorimor");
        studentData[23] = new Student("Diann", "Palomba", 23, "Los Angeles");
        studentData[24] = new Student("Dwight", "Dambrosio", 56, "Palm Springs");
        studentData[25] = new Student("Elizebeth", "Yerger", 15, "Tarnov");
        studentData[26] = new Student("Elwanda", "Sprankle", 12, "Mill City");
        studentData[27] = new Student("Ena", "Ellefson", 21, "Seven Springs");
        studentData[28] = new Student("Ernesto", "Pouncy", 38, "Beasley");
        studentData[29] = new Student("Eugenie", "Osier", 55, "Edmonston");
        studentData[30] = new Student("Forest", "Forst", 50, "Hickory Hills");
        studentData[31] = new Student("Francine", "Faulkenberry", 9, "North Judson");
        studentData[32] = new Student("Georgette", "Armstong", 8, "Santa Ana");
        studentData[33] = new Student("Gordon", "Takahashi", 5, "New Paris");
        studentData[34] = new Student("Hugh", "Hungerford", 16, "Lorimor");
        studentData[35] = new Student("Irma", "Igoe", 33, "Los Angeles");
        studentData[36] = new Student("Isaac", "Ingraham", 46, "Palm Springs");
        studentData[37] = new Student("Jacqualine", "Tabon", 13, "Tarnov");
        studentData[38] = new Student("Janella", "Witherite", 29, "Mill City");
        studentData[39] = new Student("Ji", "Jessen", 27, "Seven Springs");
        studentData[40] = new Student("Jonah", "Gaulding", 44, "Beasley");
        studentData[41] = new Student("Jonnie", "Jelley", 53, "Edmonston");
        studentData[42] = new Student("Karisa", "Kogan", 49, "Hickory Hills");
        studentData[43] = new Student("Keely", "Klump", 25, "North Judson");
        studentData[44] = new Student("Kelsie", "Stagner", 24, "Santa Ana");
        studentData[45] = new Student("Kena", "Keesling", 18, "New Paris");
        studentData[46] = new Student("Kieth", "Kepler", 30, "Lorimor");
        studentData[47] = new Student("Lachelle", "Lott", 60, "Los Angeles");
        studentData[48] = new Student("Laquanda", "Lovins", 41, "Palm Springs");
        studentData[49] = new Student("Laquita", "Weitzel", 36, "Tarnov");
        studentData[50] = new Student("Leonardo", "Pergande", 11, "Mill City");
        studentData[51] = new Student("Leta", "Landwehr", 7, "Seven Springs");
        studentData[52] = new Student("Lezlie", "Letsinger", 39, "Beasley");
        studentData[53] = new Student("Lola", "Levingston", 42, "Edmonston");
        studentData[54] = new Student("Lorina", "Buster", 47, "Hickory Hills");
        studentData[55] = new Student("Luciano", "Lahey", 20, "North Judson");
        studentData[56] = new Student("Lucien", "Leroux", 22, "Santa Ana");
        studentData[57] = new Student("Lucrecia", "Lefevre", 40, "New Paris");
        studentData[58] = new Student("Lyman", "Laseter", 44, "Lorimor");
        studentData[59] = new Student("Lynda", "Lowe", 27, "Los Angeles");
        studentData[60] = new Student("Maragaret", "Morita", 48, "Palm Springs");
        studentData[61] = new Student("Mardell", "Recio", 53, "Tarnov");
        studentData[62] = new Student("Marguerite", "Marek", 56, "Mill City");
        studentData[63] = new Student("Marianna", "Cesar", 41, "Seven Springs");
        studentData[64] = new Student("Marilyn", "Papa", 23, "Beasley");
        studentData[65] = new Student("Marlo", "Mcclaine", 50, "Edmonston");
        studentData[66] = new Student("Marsha", "Godsey", 28, "Hickory Hills");
        studentData[67] = new Student("Martha", "Mccuen", 38, "North Judson");
        studentData[68] = new Student("Melody", "Horace", 31, "Santa Ana");
        studentData[69] = new Student("Miki", "Mcilrath", 43, "New Paris");
        studentData[70] = new Student("Nadene", "Noga", 37, "Lorimor");
        studentData[71] = new Student("Paulita", "Schanz", 26, "Los Angeles");
        studentData[72] = new Student("Pearlene", "Kerfien", 42, "Palm Springs");
        studentData[73] = new Student("Rachele", "Ferree", 45, "Tarnov");
        studentData[74] = new Student("Reginald", "Roepke", 14, "Mill City");
        studentData[75] = new Student("Roman", "Rubalcaba", 32, "Seven Springs");
        studentData[76] = new Student("Rosanne", "Drummond", 9, "Beasley");
        studentData[77] = new Student("Salley", "Schneller", 8, "Edmonston");
        studentData[78] = new Student("Sandi", "Stacey", 35, "Hickory Hills");
        studentData[79] = new Student("Sang", "Bronstein", 54, "North Judson");
        studentData[80] = new Student("Shena", "Schaner", 13, "Santa Ana");
        studentData[81] = new Student("Shin", "Strawder", 25, "New Paris");
        studentData[82] = new Student("Simone", "Murga", 11, "Lorimor");
        studentData[83] = new Student("Spring", "Ulrey", 16, "Los Angeles");
        studentData[84] = new Student("Stewart", "Pederson", 24, "Palm Springs");
        studentData[85] = new Student("Sudie", "Sang", 59, "Tarnov");
        studentData[86] = new Student("Susan", "Schnee", 34, "Mill City");
        studentData[87] = new Student("Tabetha", "Cutsforth", 60, "Seven Springs");
        studentData[88] = new Student("Tamie", "Thompkins", 18, "Beasley");
        studentData[89] = new Student("Ted", "Tynan", 33, "Edmonston");
        studentData[90] = new Student("Tillie", "Tedrow", 49, "Hickory Hills");
        studentData[91] = new Student("Timika", "Tolson", 46, "North Judson");
        studentData[92] = new Student("Torri", "Talor", 30, "Santa Ana");
        studentData[93] = new Student("Trena", "Brotzman", 10, "New Paris");
        studentData[94] = new Student("Trinity", "Lucian", 20, "Lorimor");
        studentData[95] = new Student("Ty", "Kearl", 57, "Los Angeles");
        studentData[96] = new Student("Wilford", "Ertel", 19, "Palm Springs");
        studentData[97] = new Student("Wilhelmina", "Fiorillo", 36, "Tarnov");
        studentData[98] = new Student("Willette", "Laury", 47, "Mill City");
        studentData[99] = new Student("Yang", "Yao", 21, "Seven Springs");
        studentData[100] = new Student("Yoshie", "Rogan", 58, "Beasley");
        //End of the list of students
        
        System.out.print("Enter the age (an int): ");
        searchAge = userInput.nextInt();
        userInput.nextLine();
        System.out.print("Enter the city: ");
        searchCity = userInput.nextLine();
        
        for(int index = 0; index < studentData.length; index ++){
            if(searchAge <= studentData[index].getAge()&&searchCity.equals(studentData[index].getCity()))
                System.out.println(studentData[index].getLastName()+", "+studentData[index].getFirstName()+" age: "+studentData[index].getAge()+" city: "+studentData[index].getCity());   
        }
    }
}
class Student{
    String fName;
    String lName;
    int age;
    String city;
    public Student(String ff, String ll, int aa, String cc){
        fName = ff;
        lName = ll;
        age = aa; 
        city = cc;
    }
    public String getFirstName(){
        return fName;
    }
    public String getLastName(){
        return lName;
    }
    public int getAge(){
        return age;
    }
    public String getCity(){
        return city;
    }
}