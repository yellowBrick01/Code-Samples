import java.util.Scanner;
public class PhoneNrTranslator{
    public static void main(String[] args){
        Scanner userInput = new Scanner(System.in);
        String userPhone;
        String phoneTranslated = "";
        
        System.out.print("Enter a phone number containing alphabetic characters: ");
        userPhone = userInput.nextLine();
        for(int i = 0; i <= 4; i ++){
            phoneTranslated = phoneTranslated + userPhone.substring(i, i + 1);
        }
        for(int i = 5; i < userPhone.length(); i ++){
            if(userPhone.substring(i, i + 1).equals("-"))
                phoneTranslated = phoneTranslated + userPhone.substring(i , i + 1);
            if(userPhone.substring(i, i + 1).equals("A")||userPhone.substring(i, i + 1).equals("a")||userPhone.substring(i, i + 1).equals("B")||userPhone.substring(i,i + 1).equals("b")||userPhone.substring(i, i + 1).equals("C")||userPhone.substring(i, i + 1).equals("c"))
                phoneTranslated = phoneTranslated + 2;
            if(userPhone.substring(i, i + 1).equals("D")||userPhone.substring(i, i + 1).equals("d")||userPhone.substring(i, i + 1).equals("E")||userPhone.substring(i, i + 1).equals("e")||userPhone.substring(i, i + 1).equals("F")||userPhone.substring(i, i + 1).equals("f"))
                phoneTranslated = phoneTranslated + 3;
            if(userPhone.substring(i, i + 1).equals("G")||userPhone.substring(i, i + 1).equals("g")||userPhone.substring(i, i + 1).equals("H")||userPhone.substring(i, i + 1).equals("h")||userPhone.substring(i, i + 1).equals("I")||userPhone.substring(i, i +1).equals("i"))
                phoneTranslated = phoneTranslated + 4;
            if(userPhone.substring(i, i + 1).equals("J")||userPhone.substring(i, i + 1).equals("j")||userPhone.substring(i, i + 1).equals("K")||userPhone.substring(i, i + 1).equals("k")||userPhone.substring(i, i + 1).equals("L")||userPhone.substring(i, i + 1).equals("l"))
                phoneTranslated = phoneTranslated + 5;
            if(userPhone.substring(i, i + 1).equals("M")||userPhone.substring(i, i + 1).equals("m")||userPhone.substring(i, i + 1).equals("N")||userPhone.substring(i, i + 1).equals("n")||userPhone.substring(i, i + 1).equals("O")||userPhone.substring(i, i + 1).equals("o"))
                phoneTranslated = phoneTranslated + 6;
            if(userPhone.substring(i, i + 1).equals("P")||userPhone.substring(i, i + 1).equals("p")||userPhone.substring(i, i + 1).equals("Q")||userPhone.substring(i, i + 1).equals("q")||userPhone.substring(i, i + 1).equals("R")||userPhone.substring(i, i + 1).equals("r")||userPhone.substring(i, i + 1).equals("S")||userPhone.substring(i, i + 1).equals("s"))
                phoneTranslated = phoneTranslated + 7;
            if(userPhone.substring(i, i + 1).equals("T")||userPhone.substring(i, i + 1).equals("t")||userPhone.substring(i, i + 1).equals("U")||userPhone.substring(i, i + 1).equals("u")||userPhone.substring(i, i + 1).equals("V")||userPhone.substring(i, i + 1).equals("v"))
                phoneTranslated = phoneTranslated + 8;
            if(userPhone.substring(i, i + 1).equals("W")||userPhone.substring(i, i + 1).equals("w")|| userPhone.substring(i, i + 1).equals("X")||userPhone.substring(i, i + 1).equals("x")||userPhone.substring(i, i + 1).equals("Y")||userPhone.substring(i, i + 1).equals("y")||userPhone.substring(i, i +1).equals("Z")||userPhone.substring(i, i + 1).equals("z"))
                phoneTranslated = phoneTranslated + 9;
        }
        System.out.print("The numeric version of that number is "+ phoneTranslated);
    }
}    