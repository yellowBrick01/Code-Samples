import java.util.*;

public class SetOperations{
    public static void main(String [] args){
        Set <String> set_one = new LinkedHashSet<>();
        Set <String> set_two = new LinkedHashSet<>();
        Scanner userInput = new Scanner(System.in);
        String place_holder = "";
        
        while(!place_holder.equals("0")){
            System.out.print("enter next element of first set (end with 0): ");
            place_holder = userInput.nextLine();
            if(!place_holder.equals("0"))
                set_one.add(place_holder);
        }
         
        System.out.println("==============");
        place_holder = "";
        
        while(!place_holder.equals("0")){
            System.out.print("enter next element of second set (end with 0): ");
            place_holder = userInput.nextLine();
            if(!place_holder.equals("0"))
                set_two.add(place_holder);
        }
        
        System.out.println("set1: "+set_one);
        System.out.println("set2: "+set_two);
        
        Set<String> set_three = new LinkedHashSet<>();
        Iterator <String> iterator_one = set_one.iterator();
        while(iterator_one.hasNext()){
            set_three.add(iterator_one.next());
        }
        
        System.out.println("The union of the two sets is "+set_three);
        
        Set <String> difference_set = new LinkedHashSet<String>(set_one);
        difference_set.removeAll(set_two);
        System.out.println("The difference of the two sets is "+difference_set);
        
        Set <String> intersection_set = new LinkedHashSet <String>(set_one);
        intersection_set.retainAll(set_two);
        System.out.println("The intersection of the two sets is " +intersection_set);
    }
}