class CourseGrades{ 

   GradedActivity[] grades = new GradedActivity[4];
   
   void setLab(GradedActivity l){
        grades[0] = l;        
    }
    void setPassFailExam (PassFailExam pfe){
        grades[1] = pfe;
    }
    void setEssay (Essay  e){
        grades[2] = e;
    }
    void setFinalExam(FinalExam  fe){
        grades[3] = fe;
    }
}
class Essay extends GradedActivity{
    
}
class LabActivity extends GradedActivity{
    
}