public class PassFailExam extends GradedActivity{
    private int numQuestions;
    private double pointsEach;
    private int numMissed;
    
    public PassFailExam(int questions, int missed, double minPassing){
        
    }
}