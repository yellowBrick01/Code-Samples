import java.util.*;
public class AddOrMultiplyNNumbers{
    public static void main(String [] args){
        Scanner userInput = new Scanner(System.in);
        int userNumber;
        int factorialCount;
        int i;
        String operation;
        
        System.out.print("enter an integer number: ");
        userNumber = userInput.nextInt();
        
        while(userNumber != 0){
            userInput.nextLine();
            System.out.print("enter either 'a' or 'm': ");
            operation = userInput.nextLine();
            if(operation.contains("a")){
                factorialCount = 1;
                for(i = 2; i <= userNumber; i++){
                    factorialCount = factorialCount + i;
                }
                System.out.println(factorialCount);
            }else{
                factorialCount = 1;
                for(i = 2; i <= userNumber; i++){
                    factorialCount = factorialCount * i;
                }
                System.out.println(factorialCount);
            }
            System.out.print("enter an integer number: ");
            userNumber = userInput.nextInt();
        }
    }
}    