import java.util.Scanner;

public class CountVowels {
    public static void main (String[] args){
        Scanner userInput = new Scanner(System.in);
        String str;
        int vowels = 0;
        
        System.out.print("enter a string: ");
        str = userInput.nextLine();
        String vowelsTest = str.toLowerCase();
        
        if(vowelsTest.contains("a")){
            vowels = vowels + 1;
            if(vowelsTest.contains("e")){
                vowels = vowels +1;
                if(vowelsTest.contains("i")){
                    vowels = vowels + 1;
                    if(vowelsTest.contains("o")){
                        vowels= vowels + 1;
                        if(vowelsTest.contains("u")){
                            vowels = vowels +1;
                        }
                    }
                }
            }
        }else{
            if(vowelsTest.contains("e")){
                vowels = vowels + 1;
                if(vowelsTest.contains("i")){
                    vowels = vowels + 1;
                    if(vowelsTest.contains("o")){
                        vowels = vowels + 1;
                        if(vowelsTest.contains("u")){
                            vowels = vowels + 1;
                        }
                    }
                }
            }else{
                if(vowelsTest.contains("i")){
                    vowels = vowels + 1;
                    if(vowelsTest.contains("o")){
                        vowels = vowels + 1;
                        if(vowelsTest.contains("u")){
                            vowels = vowels + 1;
                        }
                    }
                }else{
                    if(vowelsTest.contains("o")){
                        vowels = vowels + 1;
                        if(vowelsTest.contains("u")){
                            vowels = vowels + 1;
                        }
                    }else{
                        if(vowelsTest.contains("u")){
                            vowels = vowels + 1;
                        }
                    }
                }
            }
        }
        if(vowels <=0){
            System.out.println("there are no vowels in string: " + "\""+str+"\"");
        }
        if(vowels > 1){
            System.out.println("there are " +vowels+ " different vowels in string: " +"\""+str+"\"");
        }
        if(vowels == 1){
            System.out.println("there is one vowel in string: \"" +str+ "\"");
        }
    }
}