import java.util.*;
public class HelloJon{
    public static void main(String [] args){
        Scanner userInput = new Scanner(System.in);
        String userName;
        System.out.print("enter your name: ");
        userName = userInput.nextLine();
        System.out.println("hello "+userName+"!");
    }
}

    