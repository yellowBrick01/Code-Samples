import java.util.Scanner;
import java.util.ArrayList;
public class Stats {

    public static TreeNode tree;

    //add whatever methods you need here
        
    public static void main(String [] args){
        Scanner input = new Scanner(System.in);
        System.out.print("please enter an int: ");
        int ll = input.nextInt();
        //the integer read from the user determines which tree is
        //going to be used
        
        TreeFactory factory = new TreeFactory();
        //the Tree factory creates a different Tree for each integer
        tree = factory.getTree(ll);
        //display your tree here
        System.out.println("=========");
        //count maxDepth and nr of nodes here
        System.out.println("maxDepth: " + maxDepth);
        System.out.println("nr of nodes: " + nrNodes);
    }
}
