import java.util.*;

public class Excp01{
    public static void main(String [] args){
        myMethod();
    }
    static void myMethod(){
        int number_to_loop = 0; 
        int user_number = 0;        
        double average = 0; 
        int sum_of_user_numbers = 0;
        int test01 = 1;
        boolean i_have_to_repeat = false;
        
        do{
            try{
                Scanner sOne = new Scanner(System.in);
                if(!i_have_to_repeat){
                    System.out.print("enter nr of integers (max 10) to be processed: ");
                    number_to_loop = sOne.nextInt();
                }else{
                    number_to_loop = sOne.nextInt();
                }
                if(number_to_loop <= 9){
                    test01 = 2;
                    sOne.close();
                }
                if(number_to_loop == 10){
                    i_have_to_repeat = true;
                    System.out.print("try again, enter an int: ");
                    continue;
                }
                if(number_to_loop > 10){
                    i_have_to_repeat = true;
                    System.out.print("out of bounds, try again, enter an int: ");
                    continue;
                }
            }catch(InputMismatchException e){
                System.out.print("try again, enter an int: ");
                i_have_to_repeat = true;               
            }
        }while(test01 == 1);
        
        System.out.println("ok, now lets loop "+number_to_loop+" times");
        
        
        test01 = 1;
        i_have_to_repeat = false;
        do{
            try{
                Scanner sTwo = new Scanner(System.in);
                if(user_number < 0 || user_number > 100)
                throw new IllegalArgumentException(user_number);
                if(!i_have_to_repeat){
                    System.out.print("enter an int: ");
                    user_number = sTwo.nextInt();
                    sum_of_user_numbers = sum_of_user_numbers + user_number;                       
                    test01 ++;
                }else{
                    user_number = sTwo.nextInt();
                    sum_of_user_numbers = sum_of_user_numbers + user_number;
                    test01++;
                }
                if(test01 == number_to_loop)
                    sTwo.close();                    
            }catch(InputMismatchException e){
                System.out.print("try again, enter an int: ");
                i_have_to_repeat = true;               
            }catch(IllegalArgumentException e){
                System.out.print("Exeception thrown--number: "+user_number);
                System.exit(0);                    
            }
        }while(test01 <=number_to_loop);
            
        average = sum_of_user_numbers / number_to_loop;
        System.out.println("average is: "+average);
        
        i_have_to_repeat = false;
        test01 = 1;
        do{
            try{
                Scanner sThree = new Scanner(System.in);
                if(!i_have_to_repeat){
                    System.out.print("enter an integer less than 200: ");
                    user_number = sThree.nextInt();
                    if(user_number > 200){
                        i_have_to_repeat = true;
                        System.out.print("out of bounds, try again, enter an int: ");
                        user_number = sThree.nextInt();
                    }else{
                        System.out.println("integer was: "+user_number);                            
                        test01 = 2;  
                        sThree.close();
                    }    
                }else{
                    user_number = sThree.nextInt();
                    System.out.println("integer was: "+user_number);
                    test01 = 2;
                    sThree.close();
                }
            }catch(InputMismatchException e){
                System.out.print("try again, enter an int: ");
                i_have_to_repeat = true;               
            }                
        }while(test01 == 1);   
    }
}    
class IllegalArgumentException extends Exception{
    public IllegalArgumentException(int user_number){
        super("Exception thrown--number: "+user_number);
    }
}