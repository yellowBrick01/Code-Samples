import java.util.Scanner;

public class MultiplicationTable{
    public static void main (String [] args){
        int num;
        Scanner userInput = new Scanner(System.in);
        System.out.print("enter an interger: ");
        num = userInput.nextInt();
        
        for(int x = 1; x <=12; x ++){
            int p = x * num;
            System.out.printf("%2d * %2d = %2d%n",x,num,p);
        }   
    }
}