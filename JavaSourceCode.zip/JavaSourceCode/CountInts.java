import java.util.*;

public class CountInts{
    public static void main(String [] args){
        
        int[] arrayOfNums = new int[101];
        //The array has length of 101 to hold all
        //intergers between 0 and 100.
        //NOTE: total index = length -1
        
        giveValue(arrayOfNums);
        //This method will assign values to the array.
        //the value will keep track on how many times
        //the use enter a certain interger.
        
        displayResult(arrayOfNums);
        //This method will display the interger and how
        //many times it was used.
    }
    public static void giveValue(int[] arrayOfNums){
        Scanner userInput = new Scanner(System.in); 
        System.out.println("Enter integers between 1 and 100.");
        System.out.println("Finish by entering 0: ");
        int userNum = userInput.nextInt();
       
        while(userNum != 0){
            if(userNum >= 1 && userNum<=100){
                arrayOfNums[userNum]++;
                //This will add 1 to the index that corresponds
                //to the number that user inputed.
                //Example: if the user enters 3, the program will
                //add 1 to the third index of the array.
           
                userNum = userInput.nextInt();
            }else{
                userNum = userInput.nextInt();
            }
        }
    }
    public static void displayResult(int[] arrayOfNums){
        for(int i = 1; i < arrayOfNums.length; i++){
            if(arrayOfNums[i] > 0){
                if(arrayOfNums[i] == 1){
                    System.out.println(i+" occurs "+arrayOfNums[i]+" time");
                }else{
                    System.out.println(i+" occurs "+arrayOfNums[i]+" times");
                }
            }
        }
    }
}