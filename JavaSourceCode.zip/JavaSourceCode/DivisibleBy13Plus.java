import java.util.Scanner;

public class DivisibleBy13Plus
{
    public static void main (String[] agrgs)
    {
        int n;
        Scanner userInput = new Scanner(System.in);
        
        System.out.print("Enter any integer: ");
        n = userInput.nextInt();
        
        if(n % 13 == 0 || n % 17 == 0 || n % 19 == 0)
            {
                System.out.println(n + " is divisible by 13, 17 or 19");
            }
        else
            {
                System.out.println(n + " is NOT divisible by any of 13, 17 or 19");
            }
    }
}       