import java.util.*;

public class OddChar{
    public static void main(String [] args){
        Scanner userInput = new Scanner(System.in);
        String userString;
        //Will hold the string the user creates.
        String oddStrig;
        //Will hold all the odd character from the
        //user input.
        int lengthOfString;
        //Will determine how long is the for loop
        //Will determine how long is the char array
        int x = 0;
        //will repersent the index of char array
        char[] oddChars;
        //The program will use this char array to hold
        //all odd characters
        
        System.out.print("enter a String: ");
        userString = userInput.nextLine();
        //prompt user to enter a string
        lengthOfString = userString.length();
        //Gets the length of the string in the
        //form of an int
        oddChars = new char[lengthOfString];
        //This is will ensure that the char 
        //array is long enough to hold all 
        //odd characters
        
        
        for(int i = 0; i < lengthOfString; i = i + 2){
            //i is set to 0 to ensue that the program includes 
            //the first character of the string.
            //i will increase by 2 because all odd chars
            //chars are in even indexes.
            //Example: the third character is in index 2
            oddChars[x] = userString.charAt(i);
            x++;
            //The two statements in the for loop will input
            //all odd characters into the char Array.
        }
        oddStrig = new String(oddChars);
        //Converts the char Array into a
        //new string.
        System.out.println(oddStrig.trim());
        //The trim method is used to remove the
        //spaces.
        
    }
}