import java.util.Scanner;
public class VerifyBST {

    public static TreeNode tree;

    public static void main(String [] args){
        Scanner input = new Scanner(System.in);
        System.out.print("please enter an int: ");
        int ll = input.nextInt();
        
        TreeFactory factory = new TreeFactory();
        tree = factory.getTree(ll);

        //if tree is BST print true, otherwise print false

        
    }
}
