import java.util.Scanner;
public class VerifyBST {

    public static TreeNode tree;

    public static void main(String [] args){
        Scanner input = new Scanner(System.in);
        System.out.print("please enter an int: ");
        int ll = input.nextInt();
        
        TreeFactory factory = new TreeFactory();
        tree = factory.getTree(ll);
        //if tree is BST print true, otherwise print false
        System.out.println(isBST(tree, Integer.MIN_VALUE, Integer.MAX_VALUE));
    }
    public static boolean isBST(TreeNode a, int min, int max){
        if(a == null){
            return true;
        }
        if(Integer.parseInt(a.item) > min && Integer.parseInt(a.item) < max){
            boolean leftBST = isBST(a.left, min, Integer.parseInt(a.item));
            boolean rightBST = isBST(a.right, Integer.parseInt(a.item), max);
            return leftBST && rightBST;
        }else{
            return false;
        }            
    }
}
