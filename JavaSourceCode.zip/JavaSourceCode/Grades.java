import java.util.Scanner;

public class Grades
{
    public static void main (String[] agrgs)
    {
        String n;
        Scanner userInput = new Scanner(System.in);
        
        System.out.print("enter a number grade: ");
        n = userInput.nextLine();
        
        if(n.equals("0.0") || n.equals("0.5") || n.equals("1.0") || n.equals("1.5") || n.equals("2.0") || n.equals("2.5") || n.equals("3.0") || n.equals("3.5") || n.equals("4.0") || n.equals("4.5") || n.equals("5.0"))
            {
                System.out.println("letter grade is F");
            }
            else
            {
                if(n.equals("5.5") || n.equals("6.0"))
                {
                    System.out.println("letter grade is D");
                }
                else
                {
                    if(n.equals("6.5") || n.equals("7.0"))
                    {
                        System.out.println("letter grade is C");
                    }
                    else
                    {
                        if(n.equals("7.5") || n.equals("8.0"))
                        {
                            System.out.println("letter grade is B");
                        }
                        else
                        {
                            if(n.equals("8.5") || n.equals("9.0") || n.equals("9.5") || n.equals("10.0"))
                            {
                                System.out.println("letter grade is A");
                            }
                        
                            else
                            {
                                System.out.println("ERROR: " + n);
                            }
                        }    
                    }
                }
            }
    }
}