import java.util.*;
public class MultiplyByItself{
    public static void main(String [] args){
        Scanner userInput = new Scanner(System.in);
        int numToMultiply;
        int nthPower;
        
        System.out.print("enter an integer: ");
        numToMultiply = userInput.nextInt();
        System.out.print("enter another integer: ");
        nthPower = userInput.nextInt();
       
        System.out.println(exponet(nthPower, numToMultiply));
    }
    public static int exponet(int nthPower, int numToMultiply){
        if(nthPower < 1){
            return 1;
        }else{
            return numToMultiply * exponet(nthPower - 1, numToMultiply);
        }
    }
}    