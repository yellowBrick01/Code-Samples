import java.util.Scanner;

public class Loop{
    public static void main (String [] args){
        Scanner input = new Scanner(System.in);
        int i = 0;
        for(i = 0;i < 10; i ++){
            System.out.println(i);
        }
        
    }
}