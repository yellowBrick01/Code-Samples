import java.util.*;
public class RoomSchedule{
    public static void main(String[] args){
        Scanner userInput = new Scanner(System.in);
        String time_intervals_statement;
        int num_of_rooms = 1;
        int index = 0;
        
        System.out.print("enter all time intervals: ");
        time_intervals_statement = userInput.nextLine();
        
        StringTokenizer checkFormat = new StringTokenizer(time_intervals_statement, "1234567890 ");
        String formatChecker = "";
        while(checkFormat.hasMoreTokens()){
            formatChecker = formatChecker + checkFormat.nextToken();
        }
        for(int i = 0; i < formatChecker.length() ; i ++){
            
        }
        StringTokenizer token = new StringTokenizer(time_intervals_statement, "(), ");
        ArrayList <Integer> list_of_time_intervals = new ArrayList<Integer>();
        while(token.hasMoreTokens()){
            list_of_time_intervals.add(Integer.parseInt(token.nextToken()));
        }
        for(int i = 0; i < list_of_time_intervals.size(); i += 2){
            if(i == list_of_time_intervals.size()){
                System.out.println("wrong format!");
            }else{
                if(list_of_time_intervals.get(i) >= list_of_time_intervals.get(i + 1))
                    System.out.println("wrong format!");
            }
        }
        for(int i = 2; i < list_of_time_intervals.size(); i+= 2){
            if(list_of_time_intervals.get(i) >= list_of_time_intervals.get(0) && list_of_time_intervals.get(i) <= list_of_time_intervals.get(1))
                num_of_rooms++;
            
        }
        System.out.print("minimum nr of rooms: "+num_of_rooms);
    }
}