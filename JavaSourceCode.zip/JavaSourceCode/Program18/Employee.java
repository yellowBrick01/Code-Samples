class Employee{
    String employeeName;
    String employeeNumber;
    String hireDate;
    
    void setName(String name){
        employeeName = name;
    }
    String getName(){
        return employeeName;
    }
    void setNumber(String number){
        employeeNumber = number;
    }
    String getNumber(){
        return employeeNumber;
    }
    void setHire(String date){
        hireDate = date;
    }
    String getHire(){
        return hireDate;
    }
    
}
class ProductionWorker extends Employee{
    int shift;
    double hourly_pay_rate;
    
    void setShift(int i){
        shift = i;
    }
    int getShift(){
        return shift;
    }
    void setPayRate(double pay){
        hourly_pay_rate = pay;
    }
    double getPayRate(){
        return hourly_pay_rate;
    }
}