class ShiftSupervisor extends Employee{
    double annual_salary;
    double annual_production_bonus;
    
    void setAnnualSalary(double year_salary){
        annual_salary = year_salary;
    }
    double getAnnualSalary(){
        return annual_salary;
    }
    void setAnnualProductionBonus(double year_p_bonus){
        annual_production_bonus = year_p_bonus;
    }
    double getAnnualProductionBonus(){
        return annual_production_bonus;
    }
}
class TeamLeader extends Employee{
    double mountly_bonus;
    int required_training_hours;
    int attended_training_hours;
    
    void setMonthlyBonus(double mBonus){
        mountly_bonus = mBonus;
    }
    double getMonthlyBonus(){
        return mountly_bonus;
    }
    void setRequiredTrainingHours(int rtHours){
        required_training_hours = rtHours;
    }
    int getRequiredTrainingHours(){
        return required_training_hours;
    }
    void setAttendedTrainigHours(int atHours){
        attended_training_hours = atHours;
    }
    int getAttendedTrainingHours(){
        return attended_training_hours;
    }
}