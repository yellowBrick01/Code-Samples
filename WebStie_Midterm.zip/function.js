function getTotal()
{
    num1 = document.getElementById("firstNumber").value;
    num2 = document.getElementById("secondNumber").value;
    num3 = document.getElementById("thirdNumber").value;
    
    document.getElementById("result").innerHTML = num1 * 6 + num2 * 124 + num3 * 332;
}