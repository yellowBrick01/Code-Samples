CREATE TABLE region(
    region_id int (4)
    , region_name varchar (20)
    , region_professor varchar (20)
);

INSERT INTO region (region_id , region_name , region_professor) VALUES ('1','Kanto','Professor Oak');
INSERT INTO region (region_id , region_name , region_professor) VALUES ('2','Johto','Professor Elm');
INSERT INTO region (region_id , region_name , region_professor) VALUES ('3','Hoenn','Professor Birch');
INSERT INTO region (region_id , region_name , region_professor) Values ('4','Sinnoh','Professor Rowan');