/*
The table will focus on the main games in the pokemon series.
Moreover, this table will aslo exculde remakes.
The table will only include one game per region.
*/
CREATE TABLE game(
    game_id int (7)
    , game_name varchar(20)
    , release_date date
    /* This table will only have the  North American release date */
);

INSERT INTO game (game_id , game_name , release_date) VALUES ('1','Red Version','1998-09-28');
INSERT INTO game (game_id , game_name , release_date) VALUES ('2','Gold Version','2000-10-15');
INSERT INTO game (game_id , game_name , release_date) VALUES ('3','Ruby Version','2003-03-19');
INSERT INTO game (game_id , game_name , release_date) VALUES ('4','Diamond Version','2007-04-22');