CREATE TABLE pokemon(
    pokemon_id int(30)
    , pokemon_name varchar(20)
    , pokemon_type varchar(20)
);

INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('1','Bulbasaur','Grass-Poison');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('2','Ivysaur','Grass-Poison');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('3','Venusaur','Grass-Poison');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('4','Charmander','Fire');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('5','Charmelon','Fire');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('6','Charizard','Fire-Flying');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('7','Squirtle','Water');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('8','Wartortle','Water');
INSERT INTO pokemon (pokemon_id , pokemon_name , pokemon_type) VALUES ('9','Blastoise','Water');